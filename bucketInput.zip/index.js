
/**
 * Background Cloud Function to be triggered by Cloud Storage.
 *
 * @param {object} event The Cloud Functions event.
 * @param {function} callback The callback function.
 */
const http = require("http");
const curl = require('curlrequest');
const storage = require('@google-cloud/storage')();
const request = require('request');
var FormData = require('form-data');
const fs = require("fs");


exports.processFile = function (event, callback) {
  
  const object = event.data;
  
  const imgfile = storage.bucket(object.bucket).file(object.name);

  let str = JSON.stringify(object);
  let strFile = JSON.stringify(imgfile);
  
  //console.log(`Object: ${object}`);
  console.log(`File: ${imgfile.name}`);
  console.log(`File Bucket: ${object.bucket}`);
  
  //console.log(`Image file: ${imgfile}`);
  //console.log(`JSON obj: ${str}`, null, 4);
  //console.log(`JSON imgfile: ${strFile}`, null, 4);

  
  
  
  var formData = {
    "name" : 'bucketfiletoupload',
    "filename" : object.name,
    "bucket" : object.bucket,
    
  };

  request.post({url:'http://35.189.222.193:3000/fileupload', formData: formData}, function(err, httpResponse, body) {
    if (err) {
      return console.error('upload failed:', err);
    }
    console.log('Upload successful!  Server responded with:');
    //console.log('Upload successful!  Server responded with:', body);
  }); 

  


};

